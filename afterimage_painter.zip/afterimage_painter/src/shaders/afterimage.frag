// TODO: afterimage.frag
