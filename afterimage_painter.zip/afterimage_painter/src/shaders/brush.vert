// TODO: brush.vert
