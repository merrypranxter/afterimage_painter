// TODO: decay.frag
