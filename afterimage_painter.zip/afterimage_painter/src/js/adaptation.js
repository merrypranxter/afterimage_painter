// FBO feedback adaptation buffer
