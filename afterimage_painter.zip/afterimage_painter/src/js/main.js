// Afterimage painter renderer and brush logic
