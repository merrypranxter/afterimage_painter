// Opponent color channel inversion
