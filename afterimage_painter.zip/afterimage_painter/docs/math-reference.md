# Math Reference: afterimage_painter

> TODO: add mathematical foundations, equations, and reference values.
