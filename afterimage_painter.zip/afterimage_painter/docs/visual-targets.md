# Visual Targets: afterimage_painter

> TODO: describe desired visual output, color palettes, and animation behavior.
