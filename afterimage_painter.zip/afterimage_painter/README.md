# afterimage_painter

> paint with color. burn it in. watch the ghost.

Interactive afterimage painting system. Paint with saturated colors on the screen; holding the brush increases retinal adaptation. When you release, a vivid afterimage appears in the complementary color. The afterimage decays over seconds using FBO feedback for temporal adaptation simulation. The canvas is the eye.

## Live Controls

| Key | Action |
|-----|--------|
| `Mouse` | Paint with current color |
| `Hold` | Burn in (increase adaptation) |
| `Release` | View afterimage |
| `Space` | Clear canvas and adaptation buffer |
| `C` | Cycle brush color |
| `G` | Toggle gallery mode (pre-burn patterns) |
| `↑ / ↓` | Increase / decrease decay rate |

## Named Regimes

- **Free Paint** — Mouse painting with burn and release
- **Mondrian** — Pre-burn geometric pattern for strong afterimage
- **Spiral** — Rotating spiral, release to see reversed motion
- **Troxler** — Fixation dot, peripheral color fades (bonus)
- **Successive Contrast** — Rapid color switching, cumulative adaptation
- **Complementary Mix** — Two colors, overlapping afterimages

## The Math

Chromatic adaptation model (von Kries):
- L, M, S cone responses adapt to local mean
- Adaptation state: L_a(t) = L_a(t-1) + α · (L(t) - L_a(t-1))
- Afterimage signal: ΔL = L_a - L (negative when adapted to bright)
- Complementary: opponent channels (R-G, B-Y) invert

Decay function:
- Exponential decay: A(t) = A_0 · exp(-t/τ)
- τ = time constant (2–30 seconds depending on burn duration)
- Longer burn = higher A_0 and longer τ

## Acknowledgments

Johann Wolfgang von Goethe (color theory), Ewald Hering (opponent process), modern work by Fairchild and others on chromatic adaptation.
